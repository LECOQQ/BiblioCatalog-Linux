#ifndef BOOKS_H
#define BOOKS_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <utility>
#include <sstream>
#include <stdexcept>

using namespace std;

class Books {
	private:
		string title, author, type, collection, keywords;
	public:
		Books() : title(""), author(""), type(""), collection(""), keywords("") {
		}

		Books(string _author, string _title, string _collection = "N/A", string _type = "N/A", string _keywords = "N/A") : title(_title), author(_author), type(_type), keywords(_keywords), collection(_collection) {
		}

		//getters
		string getTitle() const {
			return title;
		}
		
		string getAuthor() const {
			return author;
		}

		string getType() const {
			return type;
		}

		string getCollection() const {
			return collection;
		}

		string getKeywords() const {
			return keywords;
		}

		//setters
		void setTitle(string _title) {
			title = _title;
		}

		void setAuthor(string _author) {
			author = _author;
		}

};

#endif