#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "Books.h"

ostream& operator<<(ostream& os, vector<vector<string>> v) {
	for (size_t i = 0; i < v.size(); i++) {
		for (size_t k = 0; k < v[i].size(); k++) {
			os << " | " << v[i][k];
		}
		os << " |" << endl;
	}
	return os;
}

void checkCSVFile(const string& filename) {
	ifstream myFile;
	myFile.open(filename);
	//if it can't open we create one
	if (!myFile.is_open()) {
		ofstream myFileBis(filename);
		myFileBis << "Author;Title;Collection;Type;KeyWords" << endl;
		myFileBis.close();
	}
	myFile.close();
}

void Reset(const string& filename) {
	char* char_array = new char[filename.length() + 1];
	strcpy(char_array, filename.c_str());
	if (remove(char_array) != 0) {
		perror("Can't reset");
	} else {
		puts("Reset has been done");
	}
	delete[] char_array;
}

bool sure() {
	string answer;
	cout << "Are you sure ? y/n" << endl;
	cin >> answer;
	cin.ignore();
	if (answer == "y") return 1;
	if (answer == "n") return 0;
	sure();
}

void write_books_csv(const string& filename, const Books& book) {
	ofstream myFile(filename, ios::in | ios::out | ios::app);

	myFile << book.getAuthor() << ";" << book.getTitle() << ";" << book.getCollection() << ";" << book.getType() << ";" << book.getKeywords() << endl;

	myFile.close();
}

vector<vector<string>> read_books_csv(const string& filename) {
	vector<vector<string>> result;
	string line, column;
	ifstream myFile(filename);
	if(!myFile.is_open()) throw runtime_error("Could not open file");

	//extracting column names
	if (myFile.good()) {

		while (getline(myFile, line)) {
			vector<string> col;
			stringstream ss(line);
			while (getline(ss, column, ';')) {
				col.push_back(column);
			}
			result.push_back(col);
		}
	}

	myFile.close();
	return result;
}

void addBook() {
	string title, author, type, collection, keywords;
	unsigned char choice;

	system("CLS");
	cout << "What is the title of the book ?" << endl;
	getline(cin, title);

	system("CLS");
	cout << "What is the author of the book?" << endl;
	getline(cin, author);

	system("CLS");
	cout << "From which collection does your book belong ?" << endl;
	cout << "Answer N/A if you don't want/can't answer." << endl;
	getline(cin, collection);

	system("CLS");
	Books addedBook(author, title, collection);
	write_books_csv("BiblioCatalogBooks.csv", addedBook); 

	cout << "Any other books to add ?" << endl;
	cout << "1 - Yes     2 - No" << endl;
	cin >> choice;
	cin.ignore();
	system("CLS");

	if ((int)choice - '0' == 1) {
		addBook();
	}
}

void listBooks(const string& filename) {
	vector<vector<string>> vec = read_books_csv("BiblioCatalogBooks.csv");
	system("CLS");
	cout << vec;
}

unsigned char userChoice() {
	checkCSVFile("BiblioCatalogBooks.csv");
	unsigned char choice;

	cout << "What do you want to do ?" << endl;
	cout << "1 - Add a book     2 - Leave" << endl;
	cout << "3 - Reset catalog  4 - List of my books" << endl;
	cin >> choice;		//care here cause we are only reading the char, not the newline char after. in doing so we need to erase the newline char else we cant use getline(cin,string) after
	cin.ignore();

	if ((int)choice - '0' == 1) {
		addBook();
		userChoice();
	}
	else if ((int)choice - '0' == 2) {
		return 0;
	}
	else if ((int)choice - '0' == 3) {
		if(sure()) Reset("BiblioCatalogBooks.csv");
		else userChoice();
	}
	else if ((int)choice - '0' == 4) {
		listBooks("BiblioCatalogBooks.csv");
	}
	else {
		system("CLS");
		cout << "Wrong answer, please choose again" << endl;
		userChoice();
	}

	return 0;
}

#endif